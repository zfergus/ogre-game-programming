CS 425: Game Programming
HW 06: Physics
Zachary Ferguson


Controls:

Up/Down Arrow - Change the trajectory of the fish. Reflected in the orientation
	of the fish.
Right/Left Arrow - Change the initial speed of the fish. Reflected in the speed 
	slider in the top right corner.
	
Directions:

Press the space bar to fire the fish. Attempt to hit the barrel to score points.
After every point the barrel moves forward or backwards a small amount.

Setup:
Place the include drum mesh and material file with OGRE's mesh and material 
files.