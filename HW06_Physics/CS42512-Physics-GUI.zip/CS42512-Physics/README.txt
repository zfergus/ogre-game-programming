This code demonstrates a couple of HUD widgets and moveable text. Search for Lecture 16 to find all of the code elements. There are several other widgents that may be useful. 

Unzip fonts.zip to $OGRE_HOME\media\fonts to get movable text working