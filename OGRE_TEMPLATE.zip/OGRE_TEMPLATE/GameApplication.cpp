/*
-----------------------------------------------------------------------------
Filename:    GameApplication.cpp
-----------------------------------------------------------------------------

This source file is part of the
   ___                 __    __ _ _    _
  /___\__ _ _ __ ___  / / /\ \ (_) | _(_)
 //  // _` | '__/ _ \ \ \/  \/ / | |/ / |
/ \_// (_| | | |  __/  \  /\  /| |   <| |
\___/ \__, |_|  \___|   \/  \/ |_|_|\_\_|
      |___/
Game Framework (for Ogre 1.9)
http://www.ogre3d.org/wiki/
-----------------------------------------------------------------------------
*/

#include "GameApplication.h"

GameApplication::GameApplication(void)
{
}

GameApplication::~GameApplication(void)
{
}

void GameApplication::createScene(void)
{
    // Create your scene here :)
}

int main(int argc, char *argv[])
{
    // Create application object
    GameApplication app;

    try {
        app.go();
    } catch(Ogre::Exception& e)  {
        MessageBox(NULL, e.getFullDescription().c_str(), 
			"An exception has occurred!", MB_OK | MB_ICONERROR | MB_TASKMODAL);
        std::cerr << "An exception has occurred: " <<
            e.getFullDescription().c_str() << std::endl;
    }

    return 0;
}

